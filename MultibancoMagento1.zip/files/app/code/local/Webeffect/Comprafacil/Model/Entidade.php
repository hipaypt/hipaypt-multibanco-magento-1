<?php
class Webeffect_Comprafacil_Model_Entidade
{
    public function toOptionArray()
    {
        return array(
            array(
                'value' => '10241',
                'label' => '10241'
            ),
            array(
                'value' => '11249',
                'label' => '11249'
            ),
        );
    }
}
